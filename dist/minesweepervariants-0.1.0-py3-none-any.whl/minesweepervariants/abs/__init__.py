#!/usr/bin/env python3
# -*- coding:utf-8 -*-

"""
文件夹内为抽象根类
实现位于 /impl 文件夹内
"""