from .board import Board

__all__ = ["Board"]
